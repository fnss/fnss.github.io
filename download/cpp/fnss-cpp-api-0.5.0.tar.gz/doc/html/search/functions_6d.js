var searchData=
[
  ['measurementunit',['MeasurementUnit',['../classfnss_1_1MeasurementUnit.html#af67eb0b7f034ae3ec4281fa9ca4467b4',1,'fnss::MeasurementUnit::MeasurementUnit(const std::string &amp;base)'],['../classfnss_1_1MeasurementUnit.html#ac7e5f0dca259144d5ba22f424983b517',1,'fnss::MeasurementUnit::MeasurementUnit(const std::string &amp;base, const conversionsMapType &amp;conversions)']]]
];
