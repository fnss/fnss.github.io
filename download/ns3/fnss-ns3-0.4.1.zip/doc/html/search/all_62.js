var searchData=
[
  ['basemismatchexception',['BaseMismatchException',['../classfnss_1_1MeasurementUnit_1_1BaseMismatchException.html',1,'fnss::MeasurementUnit']]]
];
