var searchData=
[
  ['document',['document',['../classrapidxml_1_1xml__attribute.html#a8b6d31d899e27f01bde35b53d98496ec',1,'rapidxml::xml_attribute::document()'],['../classrapidxml_1_1xml__node.html#adb6ad21a4590cf13d4a6a5036e3cdbbc',1,'rapidxml::xml_node::document()']]]
];
