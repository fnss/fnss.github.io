var searchData=
[
  ['quantity',['Quantity',['../classfnss_1_1Quantity.html#a588a50965c3134a25cb4783fe2962f2a',1,'fnss::Quantity::Quantity(const double &amp;value, const std::string &amp;unit, const MeasurementUnit &amp;converter)'],['../classfnss_1_1Quantity.html#a29880e8b90406c4ab30f02bcd8e1c4b9',1,'fnss::Quantity::Quantity(const double &amp;value, const MeasurementUnit &amp;converter)'],['../classfnss_1_1Quantity.html#adec7c069c5289165eb71ef5fd920a510',1,'fnss::Quantity::Quantity(const std::string &amp;str, const MeasurementUnit &amp;converter)'],['../classfnss_1_1Quantity.html#a5a352225342cc62a80f20e12910099bc',1,'fnss::Quantity::Quantity(const MeasurementUnit &amp;converter)']]]
];
